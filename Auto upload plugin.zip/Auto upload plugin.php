<?php
/*
Plugin Name: Auto Upload External Images for Elementor
Description: Automatically uploads external images to the media library and updates Elementor.
Version: 1.0
Author: Antikronios
*/
// Paste the code above here
function auto_upload_external_images($post_id) {
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) {
        return;
    }

    $post = get_post($post_id);
    if (!$post || empty($post->post_content)) {
        error_log("⚠️ Post ID $post_id is invalid or has empty content.");
        return;
    }

    $original_content = $post->post_content;
    $content = $original_content;

    preg_match_all('/<img[^>]+src=["\']((?:http|https):\/\/[^"\']+)["\']/i', $content, $matches);

    if (empty($matches[1])) {
        error_log("⚠️ No external images found in post ID $post_id.");
        return;
    }

    error_log("✅ Found " . count($matches[1]) . " external images in post ID $post_id.");
    $updated = false;

    foreach ($matches[1] as $image_url) {
        error_log("🔍 Processing Image: $image_url");
        if (strpos($image_url, get_site_url()) !== false) {
            error_log("⏩ Skipping (Already Local): $image_url");
            continue;
        }

        $new_image_url = download_image_to_media_library($image_url, $post_id);
        if ($new_image_url && $new_image_url !== $image_url) {
            error_log("✅ Replacing: $image_url with $new_image_url");
            $content = preg_replace(
                '/(<img[^>]+src=["\'])' . preg_quote($image_url, '/') . '(["\'])/i',
                '$1' . $new_image_url . '$2',
                $content
            );
            $updated = true;
        } else {
            error_log("❌ Failed to process or no change for: $image_url");
        }
    }

    if ($updated && $content !== $original_content) {
        error_log("🔍 Content changed. Original length: " . strlen($original_content) . ", New length: " . strlen($content));
        remove_action('save_post', 'auto_upload_external_images');

        $result = wp_update_post([
            'ID'           => $post_id,
            'post_content' => $content,
        ], true);

        if (is_wp_error($result)) {
            error_log("❌ Failed to update post ID $post_id: " . $result->get_error_message());
        } else {
            error_log("✅ Post ID $post_id updated successfully. Result: $result");
            // Update Elementor data
            update_elementor_images($post_id, $matches[1], $content);
            wp_cache_flush(); // Clear WordPress object cache
            if (function_exists('redis_object_cache_flush')) {
                redis_object_cache_flush(); // Clear Redis cache if plugin supports it
            }
            if (class_exists('\Elementor\Plugin')) {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
                error_log("✅ Elementor cache cleared.");
            }
            if (function_exists('rocket_clean_post')) {
                rocket_clean_post($post_id);
                error_log("✅ WP Rocket cache cleared for post ID $post_id.");
            }
            $updated_post = get_post($post_id);
            error_log("🔍 Saved content length: " . strlen($updated_post->post_content));
        }

        add_action('save_post', 'auto_upload_external_images');
    } else {
        error_log("⚠️ No update needed or content unchanged for post ID $post_id.");
    }
}

function download_image_to_media_library($image_url, $post_id) {
    $upload_dir = wp_upload_dir();
    $image_name = wp_unique_filename($upload_dir['path'], wp_basename(parse_url($image_url, PHP_URL_PATH)));
    $file_path = $upload_dir['path'] . '/' . $image_name;

    $response = wp_remote_get($image_url, ['timeout' => 30]);
    if (is_wp_error($response)) {
        error_log("❌ Failed to download image $image_url: " . $response->get_error_message());
        return false;
    }

    $image_data = wp_remote_retrieve_body($response);
    if (empty($image_data)) {
        error_log("❌ Empty response for image $image_url");
        return false;
    }

    if (file_put_contents($file_path, $image_data) === false) {
        error_log("❌ Failed to save image to $file_path");
        return false;
    }

    $file_type = wp_check_filetype($file_path);
    if (!$file_type['type']) {
        error_log("❌ Invalid file type for $image_url");
        unlink($file_path);
        return false;
    }

    $attachment = [
        'post_mime_type' => $file_type['type'],
        'post_title'     => sanitize_file_name(pathinfo($image_name, PATHINFO_FILENAME)),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ];

    $attach_id = wp_insert_attachment($attachment, $file_path, $post_id);
    if (!$attach_id) {
        error_log("❌ Failed to create attachment for $file_path");
        unlink($file_path);
        return false;
    }

    require_once ABSPATH . 'wp-admin/includes/image.php';
    $attach_data = wp_generate_attachment_metadata($attach_id, $file_path);
    wp_update_attachment_metadata($attach_id, $attach_data);

    $new_url = wp_get_attachment_url($attach_id);
    error_log("✅ Uploaded Image: $new_url");

    return $new_url;
}

function update_elementor_images($post_id, $old_urls, $new_content) {
    $elementor_data = get_post_meta($post_id, '_elementor_data', true);
    if (!$elementor_data) {
        error_log("⚠️ No Elementor data found for post ID $post_id.");
        return;
    }

    $updated = false;
    $elementor_data = json_decode($elementor_data, true);
    if (!is_array($elementor_data)) {
        error_log("❌ Elementor data is not valid JSON for post ID $post_id.");
        return;
    }

    $url_map = [];
    foreach ($old_urls as $old_url) {
        preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $new_content, $match);
        if (isset($match[1]) && strpos($match[1], get_site_url()) !== false && strpos($new_content, $old_url) === false) {
            $url_map[$old_url] = $match[1];
        }
    }

    $elementor_data = recursive_replace_elementor_urls($elementor_data, $url_map);
    update_post_meta($post_id, '_elementor_data', wp_json_encode($elementor_data));
    error_log("✅ Elementor data updated for post ID $post_id.");
}

function recursive_replace_elementor_urls(&$data, $url_map) {
    if (is_array($data)) {
        foreach ($data as &$value) {
            $value = recursive_replace_elementor_urls($value, $url_map);
        }
    } elseif (is_string($data) && isset($url_map[$data])) {
        $data = $url_map[$data];
    }
    return $data;
}

add_action('save_post', 'auto_upload_external_images');